from main.models import Genre,User,Film,Rating
from django.contrib import admin

admin.site.register(Genre)
admin.site.register(User)
admin.site.register(Film)
admin.site.register(Rating)
